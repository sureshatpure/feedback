﻿<!DOCTYPE html>
<?php
   $transactionId =$_GET['transaction_id'];
    //$transactionId ="1231213";
     $duplicate =0;
        if ($transactionId!="")
        {
            $conn = pg_connect("host=localhost port=5432 dbname=puredata user=postgres password=postgres123");
            if (!$conn)
            {
                die ("Not able to connect to PostGres --> " . pg_last_error($conn));
            }
            else
            {
                echo "Connected sucessfully";
                $sql= "SELECT transaction_id FROM feedback WHERE transaction_id =".$transactionId;
                $result = pg_query($conn, $sql);
                echo $rows = pg_num_rows($result);
                if ($rows>0)
                {
                    $duplicate =1;
                }
                else
                {
                 $duplicate =0;   
                }
            }
        }
?>
<html>
    <head>
        <title>Pon Pure Chem (P) Ltd.</title>
        <meta name="apple-mobile-web-app-capable" content="yes" />        
    <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/_all.css">
        <script type="text/javascript" src="js/jquery-1.10.0.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery.icheck.min.js"></script>
        <script type="text/javascript" src="js/jquery.validate.min.js"></script>
    </head>
    <body>
        
        <div id="header">
            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div>
                            <img src="images/logo.png" alt="Pon Pure Chem (P) Ltd.">
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        <div id="content">
            <div class="container containerContent">
                <div class="row">
                    <div class="span12">
                        <h1 class="brand">Pon Pure Chem (P) Ltd.</h1>
                    </div>
                </div>
              
            <?php if ($transactionId!=""){ ?>

            
   <!-- duplicate code start -->
 <?php if ($duplicate ==1){ ?>
               
            <div class="row">
                    <div class="span12">
                        <div class="alert alert-success" style="margin-bottom: 0; text-align:center;">                                                    
                            It appears that, we have already received feedback for the Transaction Id <strong><?php echo $transactionId; ?></strong>
                        </div>
                    </div>
                </div> <!-- End of row -->
                </div> <!-- End of content -->
            
                <!-- duplicate code end -->
            <?php } else { ?> 
                
                
                <div class="row">

                    <div class="span12">

                        <form action="feedbackaction.php" method="post" enctype="multipart/form-data" autocomplete="off" name="ppcDispatchFeedbackForm" id="ppcDispatchFeedbackForm">
                            <ul>
                                <li id="feedBackInitalQuery">
                                    <fieldset>
                                        <div class="push"></div>
                                        <h4 class="feedbackQuestion">How Satisfied are you with services of Pon Pure Chem (P) Ltd.?</h4>
                                        <label class="radio">
                                            <input class="customerFeedbak required" type="radio" name="customerFeedbak" id="isCustomerSatisfied1" value="0">
                                            <span class="radioLabel">Dissatisfied<i class="icon-remove"></i></span>
                                        </label>
                                        <label class="radio">
                                            <input class="customerFeedbak required" type="radio" name="customerFeedbak" id="isCustomerSatisfied2" value="1">
                                            <span class="radioLabel customerFeedbak">Satisfied<i class="icon-ok"></i></span>
                                        </label>                                    
                                    </fieldset>
                                </li>

                                <li>
                                    <ul id="dissatisfiedOptionsList">
                                        <li class="push"></li>
                                            <li>
                                                <div id="title310">
                                                    Select an Option for your dissatisfied response.
                                                </div>
                                                </li>   
                                            <li class="push"></li>
                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="1" name="dissatisfactionReason" id="shortage">
                                                    <span class="radioLabel">Shortage</span>
                                                </label>
                                            </div>   
                                            <fieldset> 
                                                <label class="radio answers">
                                                    <input type="radio" name="1" id="shortage1" value="Due to Leakage">
                                                    <span class="radioLabel">Due to Leakage</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="1" id="shortage2" value="Weighment difference">
                                                    <span class="radioLabel">Weighment difference</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="1" id="shortage3" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="1_others"></span>
                                                </label
                                            </fieldset>
                                        </li>

                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="2" name="dissatisfactionReason" id="quality">
                                                        <span class="radioLabel">Quality Issues</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="2" id="quality1" value="Coloured">
                                                    <span class="radioLabel">Coloured</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="2" id="quality2" value="Foreign/Dust particles">
                                                    <span class="radioLabel">Foreign/Dust particles</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="2" id="quality3" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="2_others"></span>
                                                </label
                                            </fieldset>
                                        </li>


                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="3" name="dissatisfactionReason" id="supportingDocument">
                                                    <span class="radioLabel">Supporting document availability</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="3" value="Invoice Copy">
                                                    <span class="radioLabel">Invoice Copy</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="3" value="COA">
                                                    <span class="radioLabel">COA</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="3" value="MSDS">
                                                    <span class="radioLabel">MSDS</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="3" value="TREM Card (Transport emergency card)">
                                                    <span class="radioLabel">TREM Card (Transport emergency card)</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="3" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="3_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>


                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="4" name="dissatisfactionReason" id="packingConditions">
                                                    <span class="radioLabel">Packing Condition</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="4" value="Seals">
                                                    <span class="radioLabel">Seals</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="4" value="Labels/Markings">
                                                    <span class="radioLabel">Labels/Markings</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="4" value="Aesthetic/Visual Condition">
                                                    <span class="radioLabel">Aesthetic/Visual Condition</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="4" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="4_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>


                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="5" name="dissatisfactionReason" id="unloadingShifting">
                                                    <span class="radioLabel">Unloading &amp; Shifting</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="5" id="optionsRadios2" value="Precautionary measures followed">
                                                    <span class="radioLabel">Precautionary measures followed</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="5" id="optionsRadios2" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="5_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>


                                        <li>

                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="6" name="dissatisfactionReason" id="priceDifference">
                                                    <span class="radioLabel">Price Difference &ndash; in Rate / Modvat</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="6" id="priceDifference1" value="Rate difference">
                                                    <span class="radioLabel">Rate difference</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="6" id="priceDifference2" value="Modvat Difference">
                                                    <span class="radioLabel">Modvat Difference</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="6" id="priceDifference3" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="6_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>


                                        <li>

                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="7"  name="dissatisfactionReason" id="driverDeliveryApproach">
                                                    <span class="radioLabel">Driver / Delivery Staff - Approach</span>
                                                </label>
                                            </div>

                                            <fieldset>

                                                <label class="radio answers">
                                                    <input type="radio" name="7" id="driverDeliveryApproach1" value="Honored customers request">
                                                    <span class="radioLabel">Honoured customers request</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="7" id="driverDeliveryApproach2" value="On time delivery">
                                                    <span class="radioLabel">On time delivery</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="7" id="driverDeliveryApproach3" value="Level of patience">
                                                    <span class="radioLabel">Level of patience</span>
                                                </label>
                                                <label class="radio  answers">
                                                    <input type="radio" name="7" id="driverDeliveryApproach4" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="7_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>
                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="8" name="dissatisfactionReason" id="overall">
                                                    <span class="radioLabel">Delivery Time Frame</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="8" value="Delivered not as per  schedule">
                                                    <span class="radioLabel">Delivered not as per  schedule</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="8" value="Followed it up several times">
                                                    <span class="radioLabel">Followed it up several times</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="8" value="No update on the order status">
                                                    <span class="radioLabel">No update on the order status</span>
                                                </label>
                                                <label class="radio  answers">
                                                    <input type="radio" name="8" id="driverDeliveryApproach4" value="others">
                                                    <span class="radioLabel">Others<input type="text" name="8_others"></span>
                                                </label>
                                            </fieldset>
                                        </li>
                                        <li>
                                            <div>
                                                <label class="checkbox">
                                                    <input class="dissatisfiedOption" type="radio" value="9" name="dissatisfactionReason" id="overall">
                                                    <span class="radioLabel">Overall co-operation level</span>
                                                </label>
                                            </div>

                                            <fieldset>
                                                <label class="radio answers">
                                                    <input type="radio" name="9" value="Excellent">
                                                    <span class="radioLabel">Excellent</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="9" value="Moderate">
                                                    <span class="radioLabel">Moderate</span>
                                                </label>
                                                <label class="radio answers">
                                                    <input type="radio" name="9" value="Poor">
                                                    <span class="radioLabel">Poor</span>
                                                </label>
                                            </fieldset>
                                        </li>
                                    </ul>
                                </li>
                                <li id="satisfiedOptionsList">
                                    <ul>
                                        <li>
                                            What would make the service of Pon Pure Chem (P) Ltd. even more satisfactory for you?
                                        </li>
                                        <li>
                                            <textarea rows="6" class="span10" name="customerComments" id="customerComments"></textarea>
                                        </li>
                                        <li>
                                            <div class="alert alert-success" style="margin-bottom: 0">                                                    
                                                If you would like to be contacted regarding your feedback, please provide your preferred contact information below.
                                            </div>
                                        </li>
                                        <li>
                                            <div class="push"></div>
                                            <label>Name:</label>
                                            <div class="input-prepend">
                                                <span class="add-on">
                                                    <i class="icon-user"></i>
                                                </span>
                                                <input type="text" id="customerName" name="customerName" class="required">
                                            </div>

                                            <label>Contact No:</label>
                                            <div class="input-prepend">
                                                <span class="add-on">
                                                    <i class="icon-globe"></i>
                                                </span>
                                                <input type="text" id="contactNo" name="contactNo">
                                            </div>

                                            <label>Email:</label>
                                            <div class="input-prepend">
                                                <span class="add-on">
                                                    <i class="icon-envelope"></i>
                                                </span>
                                                <input type="text" id="" name="customerEmail" id="customerEmail" class="email">
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li style="text-align: center;">
                                    <input type="hidden" name="transactionId" value="<?php echo $transactionId;?>">
                                    <input type="submit" class="btn btn-primary" id="submit" name="submit" value="Submit Feedback">
                                </li>
                            </ul>
                        </form> 

                    </div>
               <?php }?>   

                   
        
           <?php } else { ?>
                    <div class="row">
                        <div class="span12">
                                <div class="alert alert-important" style="margin-bottom: 0; text-align:center;">                                                    
                                    We need Transaction Id to proceed further!  
                                </div>
                            </div>
                    </div>

           <?php } ?>    
             
                </div> <!-- End of row -->
                </div> <!-- End of content -->
            </div><!-- Container -->
            <div id="footer">
                <div class="container">
                    <div class="row">
                        <div class="span12">
                            <div  style="text-align: center;width: 100%;">
                                <span>Copyright &COPY; 2013 All Rights Reserved</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </body>
    <script>
    $(document).ready(function(){
        
        /*
         *@Create an object for the list of the dissatisifed options
         */
        var disSatisfiedOptionsMeanings = {1 : 'Shortage',2 : 'Quality Issues',3 :'Supporting document availability',
                4:'Packing Condition',5:'Unloading & Shifting',6:'Price Difference in rate / Modvat',
              7:'Driver/delivery Staff – Approach', 8:'Delivery Time Frame', 9:'Overall co-operation level'};
        
        /*
         *@Get the dissatisfication option value 
         * for validation the option value sub options
         */
        
        $("#submit").click(function(){
            var disSatisficationReasionOption = $("input[name=dissatisfactionReason]:checked").val();
            var disSatisficationReasionOptionElement = $("input[name="+disSatisficationReasionOption+"]").val();
            //Add required class to the disSatisficationReasionOptionElement
            $("input[name="+disSatisficationReasionOption+"]").addClass('required').attr('title', '<i class="icon-exclamation-sign"></i>Please select any option for '+disSatisfiedOptionsMeanings[disSatisficationReasionOption]); 
            
        });
        
        $("#ppcDispatchFeedbackForm").validate({
            rules:{
                customerFeedbak:{
                    required:true
                },
                dissatisfactionReason:{
                    required:true
                },                
                customerName:{
                    required:true
                },
                customerEmail:{
                    required:true,
                    email:true
                }

            },
            errorClass: "help-inline",
            messages:{
                customerFeedbak:{
                    required:'<i class="icon-exclamation-sign"></i>Please select your Answer.'
                },
                dissatisfactionReason:{
                    required:'<i class="icon-exclamation-sign"></i>Please select reason for your Dissatisfaction.'
                },
                disSatisficationReasionOption:{
                    required:'<i class="icon-exclamation-sign"></i>Please select any option.'
                },
                customerName:{
                    required:'<i class="icon-exclamation-sign"></i>Customer name is required.'
                },
                customerEmail:{
                    required:'<i class="icon-exclamation-sign"></i>Email name is required.',
                    email:'<i class="icon-exclamation-sign"></i>Please enter a valid email address.'
                }
            }
/*            ,showErrors: function(errorMap, errorList) {
                $.each(this.successList, function(index, value) {                    
                    return $(value).popover("hide");
                });
                return $.each(errorList, function(index, value) {
                    var _popover;
                    _popover = $(value.element).popover({
                    trigger: "manual",
                    placement: "top",
                    title:'Please fix this.',
                    content: value.message,
                    html: "<div class=\"popover\"><div class=\"arrow\"></div><div class=\"popover-inner\"><div class=\"popover-content\"><p></p></div></div></div>"
                });
                _popover.data("popover").options.content = value.message;
                return $(value.element).popover("show");
                });
            }*/

            });
        });
        
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue'
        });
        
        /*
         * @Check the customer answer
         */
        $('.customerFeedbak').on('ifChecked', function(event){
            var customerFeedback = $(this).val();
            
            if(customerFeedback == 0)
            {
                $("#satisfiedOptionsList").hide('slow');
                $("#dissatisfiedOptionsList").show('slow');
            }
            else
            {
                $("#dissatisfiedOptionsList").hide('slow');
                $("#satisfiedOptionsList").show('slow');
            }
        });
        
        var previousSelection;
        var previousSelectionExists = false;
        $('.dissatisfiedOption').on('ifChecked', function showNext(){
            
        if(previousSelectionExists == true)
        {
            $(previousSelection).hide('slow');
        }

        //var currentSelection = $(this).parent().parent().parent().parent().children('fieldset').show('slow');
        var currentSelection = $(this).parent().parent().parent().parent().children('fieldset');

        /*
            * @Show the sub options
            */
        currentSelection.show('slow');

        /*
            * @Store the most recent selection
            */
            previousSelection = currentSelection;

        if(previousSelectionExists == false)
        {                
            /*
                * @Reset the previousSelectionExists to true
                */
            previousSelectionExists = true;
        }
    });
</script>
</html>