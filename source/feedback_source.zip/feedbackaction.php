<!DOCTYPE html>
<?php
if(isset( $_POST['submit']))
{
  $ip_address = $_SERVER['SERVER_ADDR'];
  $date = date('Y-m-d');
  $transactionId      = $_POST['transactionId'];
  $customerFeedbak    = $_POST['customerFeedbak'];
  $answer         = $customerFeedbak;
  if($answer==1){$status = 'SATISFIED';} else{$status = 'DISSATISFIED';};
  $dissatisfactionReason  = $_POST['dissatisfactionReason'];
  switch ($dissatisfactionReason) 
  {
      case "1":
          $disfactionValue = "Shortage";
          break;
      case "2":

          $disfactionValue = "Quality Issues";
          break;
      case "3":

          $disfactionValue = "Supporting document availability";
          break;
    case "4":
          $disfactionValue = "Packing Condition";
          break;
      case "5":
          $disfactionValue = "Unloading & Shifting";
          break;
      case "6":
          $disfactionValue = "Price Difference – in Rate / Modvat";
          break;    
      case "7":
          $disfactionValue = "Driver / Delivery Staff - Approach";
          break;    
      case "8":
          $disfactionValue = "Delivery Time Frame";
          break;    
      case "9":
          $disfactionValue = "Overall co-operation level";
          break;                    
  }
  if ($answer==0)
  {
    $dissatisfaction_reason_sub = $_POST[$dissatisfactionReason];
    $dis_reason_sub_val = $dissatisfaction_reason_sub;
      if($dissatisfaction_reason_sub == 'others')
      {
        $dis_reason_sub_val = $_POST[$dissatisfactionReason."_".$dissatisfaction_reason_sub];
      }
      $customer_comments    = "";
      $customerName       = "";
      $contactNo        = "";
      $customerEmail      = "";
  }
  else
  {
    $dis_reason_sub_val   ="";
    $customer_comments    = $_POST['customerComments'];
    $customerName       = $_POST['customerName'];
    $contactNo        = $_POST['contactNo'];
    $customerEmail      = $_POST['customerEmail'];
  }
    include_once("db/config.php");
   // $conn = pg_connect("host=localhost port=5432 dbname=puredata user=postgres password=postgres123");
        if (!$conn)
        {
          die ("Not able to connect to PostGres --> " . pg_last_error($conn));
        }
        else{
          //echo "Connected sucessfully";
        } 

          $sql = "INSERT INTO feedback (
                      transaction_id,
                      answer,
                      status,
                      dissatisfaction_reason,
                      dissatisfaction_reason_sub,
                      customer_comments,
                      customer_name,
                      contact_no,
                      email_id,
                      ip_address,
                      date
                      ) 
              values (
                  $transactionId,'".$answer."','".$status."',
                  '".$disfactionValue."',
                  '".$dis_reason_sub_val."',
                  '".$customer_comments."',
                  '".$customerName."',
                  '".$contactNo."',
                  '".$customerEmail."',
                  '".$ip_address."',
                  '".$date."'
                  )"; 

    $result = pg_query($conn, $sql);
    if (!$result) 
    {
        $message ="There was an error encountered ";
    }
    else
    {
      $message="Data Received. Thank you for your valuable feedback";  
    }

}
else
{
  $message="Please submit your data";
}


?>
<html>
    <head>
        <title>Pon Pure Chem (P) Ltd.</title>
        <meta name="apple-mobile-web-app-capable" content="yes" />        
    <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/_all.css">
        <script type="text/javascript" src="js/jquery-1.10.0.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery.icheck.min.js"></script>
        <script type="text/javascript" src="js/jquery.validate.min.js"></script>
    </head>
    <body>
        
        <div id="header">
            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div>
                            <img src="images/logo.png" alt="Pon Pure Chem (P) Ltd.">
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        <div id="content">
            <div class="container containerContent">
                <div class="row">
                    <div class="span12">
                        <h1 class="brand">Pon Pure Chem (P) Ltd.</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="span12">
                      <?php if (isset($_POST['submit'])) { ?>
                        <div class="alert alert-success" style="margin-bottom: 0; text-align:center;">
                      <?php }else { ?>
                        <div class="alert alert-important" style="margin-bottom: 0; text-align:center;">
                      <?php } ?>    
                             <?php echo $message; ?>
                        </div>
                    </div>
                </div> <!-- End of row -->
                </div> <!-- End of content -->
            </div><!-- Container -->
            <div id="footer">
                <div class="container">
                    <div class="row">
                        <div class="span12">
                            <div  style="text-align: center;width: 100%;">
                                <span>Copyright &COPY; 2013 All Rights Reserved</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </body>