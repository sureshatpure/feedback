<?php
		$hostname="localhost";
		$dbname="puredb";
		$user="postgres";
		$password="postgres123";

  		$conn = pg_connect("host=localhost port=5432 dbname=puredata user=postgres password=postgres123")
      					or die ("Not able to connect to PostGres --> " . pg_last_error($conn));
?> 